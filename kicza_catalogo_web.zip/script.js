const products = [
  {
    nombre: "Taladro Eléctrico 500W",
    precio: "$1,299",
    imagen: "images/taladro.jpg",
    descripcion: "Taladro con velocidad variable y mango ergonómico.",
    categoria: "Herramientas Eléctricas"
  },
  {
    nombre: "Llave Ajustable 12”",
    precio: "$149",
    imagen: "images/llave.jpg",
    descripcion: "Llave ajustable cromada de alta resistencia.",
    categoria: "Manuales"
  },
  {
    nombre: "Juego de Desarmadores",
    precio: "$249",
    imagen: "images/desarmadores.jpg",
    descripcion: "Juego de 6 desarmadores de precisión.",
    categoria: "Manuales"
  },
  {
    nombre: "Cinta Métrica 5m",
    precio: "$89",
    imagen: "images/cinta.jpg",
    descripcion: "Cinta métrica con freno y clip de cinturón.",
    categoria: "Medición"
  },
  {
    nombre: "Martillo de Uña 16 oz",
    precio: "$189",
    imagen: "images/martillo.jpg",
    descripcion: "Martillo con mango antideslizante.",
    categoria: "Manuales"
  }
];

function renderProducts(list) {
  const container = document.getElementById("productList");
  container.innerHTML = "";
  list.forEach(p => {
    container.innerHTML += `
      <div class="product">
        <img src="${p.imagen}" alt="${p.nombre}" />
        <h3>${p.nombre}</h3>
        <p>${p.descripcion}</p>
        <p><strong>${p.precio}</strong></p>
        <button onclick="contact('${p.nombre}')">Pedir</button>
      </div>
    `;
  });
}

function filterCategory(cat) {
  if (cat === "Todos") {
    renderProducts(products);
  } else {
    renderProducts(products.filter(p => p.categoria === cat));
  }
}

function contact(productName) {
  const mensaje = encodeURIComponent(`Hola, quiero más información sobre: ${productName}`);
  window.open(`https://wa.me/?text=${mensaje}`, "_blank");
}

document.getElementById("searchBar").addEventListener("input", function () {
  const query = this.value.toLowerCase();
  const filtered = products.filter(p =>
    p.nombre.toLowerCase().includes(query) || p.descripcion.toLowerCase().includes(query)
  );
  renderProducts(filtered);
});

renderProducts(products);
